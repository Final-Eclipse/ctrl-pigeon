#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
command -v brew >/dev/null || { echo 'Install Homebrew from https://brew.sh, then run this again.'; exit 1; }
brew install node@24 python@3.11
export PATH="$(brew --prefix node@24)/bin:$PATH"
"$(brew --prefix python@3.11)/bin/python3.11" -m venv .venv
.venv/bin/python -m pip install -r agent/requirements.txt
(cd gateway && npm ci && npm run check)
[ -f gateway/.env ] || cp gateway/.env.example gateway/.env
[ -f agent/.env ] || cp agent/.env.example agent/.env
chmod 600 gateway/.env agent/.env
cat <<'TEXT'
Dependencies installed. Fill in gateway/.env and agent/.env.
Install the signed CuaDriver macOS application using https://cua.ai/docs/cua-driver/quickstart.
Keep the CLI and daemon versions compatible; this project pins Python cua-driver 0.34.1.
Run: open -n -g -a CuaDriver --args serve
Run: cua-driver permissions grant
System Settings > Privacy & Security > Accessibility: enable CuaDriver.
System Settings > Privacy & Security > Screen & System Audio Recording: enable CuaDriver.
On older macOS versions the second panel is named Screen Recording.
Relaunch the driver when macOS asks. No microphone permission is needed.
TEXT
