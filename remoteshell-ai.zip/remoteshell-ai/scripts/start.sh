#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
export PATH="$(brew --prefix node@24)/bin:$PATH"
export PATH="$PWD/.venv/bin:$PATH"
[ -f agent/.env ] && [ -f gateway/.env ] || { echo 'Run scripts/setup_mac.sh and fill in both .env files.'; exit 1; }
.venv/bin/python - <<'PY'
from dotenv import dotenv_values
left=dotenv_values('agent/.env');right=dotenv_values('gateway/.env')
for key,default in [('AGENT_SHARED_SECRET',''),('AGENT_PORT','8765'),('TASK_TIMEOUT_S','120')]:
    if left.get(key,default)!=right.get(key,default):
        raise SystemExit('The two .env files disagree on '+key)
PY
cua-driver status
.venv/bin/python -m agent.main &
agent_pid=$!
gateway_pid=''
cleanup() {
  trap - INT TERM EXIT
  if [ -n "$gateway_pid" ]; then
    kill -TERM "$gateway_pid" 2>/dev/null || true
    wait "$gateway_pid" || true
  fi
  kill -TERM "$agent_pid" 2>/dev/null || true
  wait "$agent_pid" || true
}
trap cleanup INT TERM EXIT
.venv/bin/python - <<'PY'
import time,urllib.request
from dotenv import dotenv_values
port=dotenv_values('agent/.env').get('AGENT_PORT','8765')
for i in range(40):
    try:
        with urllib.request.urlopen('http://127.0.0.1:'+port+'/health',timeout=1) as response:
            if response.status==200:break
    except Exception:time.sleep(.25)
else:raise SystemExit('Agent did not become healthy; inspect its startup error.')
PY
(cd gateway && exec node --import tsx src/index.ts) &
gateway_pid=$!
wait "$gateway_pid"
