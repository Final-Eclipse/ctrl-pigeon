import asyncio
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch, AsyncMock
from pydantic import ValidationError
from fastapi.testclient import TestClient
from agent.models import Plan, Step, Deck
from agent.safety import check_step, SafetyError, output_path
from agent.skills.slides import create_presentation

class CoreTests(unittest.TestCase):
    def test_schema_and_safety(self):
        base=dict(id=1,action='run_applescript',target_app='Keynote',params={'script':'do shell script "sudo x"'},success_check='done',timeout_s=15)
        with self.assertRaises(SafetyError):check_step(Step(**base))
        base.update(action='open_app',target_app='Terminal',params={})
        with self.assertRaises(SafetyError):check_step(Step(**base))
        base.update(target_app='Calculator')
        check_step(Step(**base))
        with self.assertRaises(ValidationError):Plan(goal='x',steps=[Step(**base)]*13)
        with self.assertRaises(SafetyError):output_path('../../etc/passwd')

    def test_auth_idempotency_cancel_and_recovery(self):
        from agent import main
        async def slow(self,text):await asyncio.sleep(20)
        env={'AGENT_SHARED_SECRET':'x'*64,'OPENROUTER_API_KEY':'test','VISION_MODEL':'test','TASK_TIMEOUT_S':'120'}
        with patch.dict(os.environ,env),patch('agent.main.Executor.run',slow):
            main.jobs.clear()
            with TestClient(main.app) as client:
                body={'id':'12345678-1234-1234-1234-123456789abc','text':'test'}
                headers={'x-agent-secret':'x'*64}
                self.assertEqual(client.post('/task',json=body).status_code,401)
                self.assertEqual(client.post('/task',json=body,headers=headers).status_code,200)
                self.assertEqual(client.post('/task',json=body,headers=headers).status_code,200)
                self.assertEqual(len(main.jobs),1)
                self.assertEqual(client.post('/task',json={**body,'text':'different'},headers=headers).status_code,409)
                self.assertEqual(client.post('/task/'+body['id']+'/cancel',json={},headers=headers).status_code,200)
                self.assertEqual(client.get('/task/'+body['id'],headers=headers).json()['state'],'cancelled')
                self.assertTrue(client.get('/health').json()['ok'])
                self.assertEqual(client.post('/task',json={**body,'id':'22345678-1234-1234-1234-123456789abc'},headers=headers).status_code,200)

    def test_deck_generation_no_duplicate_file_on_retry(self):
        from pptx import Presentation
        with tempfile.TemporaryDirectory() as tmp:
            home=Path(tmp);(home/'Desktop').mkdir()
            planner=AsyncMock();planner.deck.return_value=Deck(slides=[{'title':'RemoteShell AI','bullets':['Text your Mac','Generate a deck','Preserve your cursor']}]*3)
            cua=AsyncMock()
            async def windows(app):return [{'title':p.stem} for p in (home/'Desktop').glob('*.pptx')]
            cua.list_windows.side_effect=windows
            checkpoint={}
            with patch('agent.safety.Path.home',return_value=home),patch('agent.skills.slides.command',new=AsyncMock()):
                asyncio.run(create_presentation('RemoteShell',planner=planner,cua=cua,checkpoint=checkpoint))
                asyncio.run(create_presentation('RemoteShell',planner=planner,cua=cua,checkpoint=checkpoint))
            files=list((home/'Desktop').glob('*.pptx'))
            self.assertEqual(len(files),1)
            self.assertEqual(len(Presentation(files[0]).slides),3)
            self.assertEqual(planner.deck.await_count,1)

if __name__=='__main__':unittest.main()
