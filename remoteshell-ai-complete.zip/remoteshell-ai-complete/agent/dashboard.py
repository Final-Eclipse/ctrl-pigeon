"""Read-only, token-protected local task dashboard. No new dependencies."""
import hmac
import os
import secrets
from pathlib import Path
from fastapi import Header, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse

_TOKEN = secrets.token_urlsafe(32)

def dashboard_url():
    return f"http://127.0.0.1:{int(os.environ.get('AGENT_PORT', '8765'))}/dashboard#token={_TOKEN}"

def install_dashboard(app, jobs):
    @app.get('/dashboard', include_in_schema=False)
    async def dashboard():
        nonce = secrets.token_urlsafe(20)
        html = Path(__file__).with_name('dashboard.html').read_text().replace('__NONCE__', nonce)
        return HTMLResponse(html, headers={
            'Cache-Control': 'no-store', 'Referrer-Policy': 'no-referrer',
            'X-Content-Type-Options': 'nosniff',
            'Content-Security-Policy': f"default-src 'none'; script-src 'nonce-{nonce}'; style-src 'nonce-{nonce}'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'"
        })

    @app.get('/dashboard/state', include_in_schema=False)
    async def dashboard_state(x_dashboard_token: str | None = Header(default=None)):
        if not x_dashboard_token or not hmac.compare_digest(x_dashboard_token.encode(), _TOKEN.encode()):
            raise HTTPException(401, 'Open the dashboard link printed by the agent.')
        entries = list(jobs.items())
        counts = {s: sum(j['state'] == s for _, j in entries) for s in ('queued','running','completed','failed','cancelled')}
        tasks = [{'id': key, 'state': j['state'], 'text': j['text'], 'events': j['events'][-60:]} for key, j in reversed(entries[-25:])]
        return JSONResponse({'counts': counts, 'tasks': tasks}, headers={'Cache-Control': 'no-store'})
