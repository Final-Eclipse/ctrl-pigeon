import asyncio
import json

class DriverError(Exception):
    pass
class ClickMissedError(DriverError):
    pass
class AppLaunchError(DriverError):
    pass
class ActionTimeoutError(DriverError):
    pass
class ElementNotFoundError(DriverError):
    pass

async def command(*args, timeout=15):
    proc = None
    try:
        proc = await asyncio.create_subprocess_exec(*args, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        out, err = await asyncio.wait_for(proc.communicate(), timeout)
        if proc.returncode:
            raise DriverError(f'{args[0]} failed (exit {proc.returncode})')
        return out.decode()
    except (asyncio.CancelledError, TimeoutError):
        if proc is not None and proc.returncode is None:
            proc.kill()
            await proc.wait()
        raise
    except OSError as exc:
        raise DriverError(f'{args[0]} unavailable') from exc

class Cua:
    # Verified CLI contract: https://cua.ai/docs/cua-driver/reference/cli/mcp
    # Uses the installed daemon rather than importing native bindings into FastAPI.
    async def call(self, tool, params, timeout=15):
        try:
            raw = await command('cua-driver','call',tool,json.dumps({'session':'remoteshell',**params}),timeout=timeout)
            data = json.loads(raw)
            if data.get('isError') or data.get('is_error'):
                raise DriverError('Driver refused the operation')
            # VERIFY: check JSON envelope on the installed signed release.
            # https://cua.ai/docs/cua-driver/reference/cli/mcp
            structured = data.get('structuredContent', data)
            if not isinstance(structured, dict):
                raise DriverError('Unexpected driver response')
            return structured
        except TimeoutError as exc:
            raise ActionTimeoutError('Driver timed out; effect may be unknown') from exc
        except (ValueError, TypeError) as exc:
            raise DriverError('Driver response was not structured JSON') from exc

    async def list_windows(self, app):
        data = await self.call('list_windows', {})
        return [w for w in data.get('windows', []) if w.get('app_name') == app]

    async def window(self, app):
        windows = await self.list_windows(app)
        if len(windows) != 1:
            raise ElementNotFoundError(f'Expected one {app} window; found {len(windows)}')
        return windows[0]

    async def open_app(self, app, urls=None):
        try:
            result = await self.call('launch_app', {'name': app, 'urls': urls or []})
            if result.get('self_activation_suppressed') is False:
                raise AppLaunchError('App self-activated despite background launch')
            return result
        except DriverError as exc:
            raise AppLaunchError(str(exc)) from exc

    async def get_ui_tree(self, app, screenshot=None):
        w = await self.window(app)
        args = {'pid':w['pid'],'window_id':w['window_id'], 'tree_format':'elements',
                'include_screenshot':bool(screenshot), 'include_accessibility_tree':True}
        if screenshot:
            args['screenshot_out_file'] = str(screenshot)
        result = await self.call('get_window_state', args)
        result['_target'] = {'kind':'window','pid':w['pid'],'window_id':w['window_id']}
        return result

    async def screenshot(self, app, path):
        return await self.get_ui_tree(app, screenshot=path)

    def element(self, state, label):
        found = [e for e in state.get('elements',[]) if e.get('label') == label]
        if len(found) != 1:
            raise ElementNotFoundError('Element label absent or ambiguous')
        return found[0]['element_token']

    async def click(self, app, params, state):
        args = {'target':state['_target'], 'delivery_mode':'background'}
        if params.get('label'):
            args['element_token'] = self.element(state, params['label'])
        else:
            if not state.get('capture_id') or params.get('capture_id') != state['capture_id']:
                raise ElementNotFoundError('Coordinate click needs the current capture ID')
            args.update({k:params[k] for k in ['x','y','capture_id']})
        return await self.call('click', args)

    async def type_text(self, app, params, state):
        return await self.call('type_text', {'target':state['_target'], 'delivery_mode':'background',
            'element_token':self.element(state,params['label']), 'text':params['text']})

    async def key_combo(self, app, keys, state):
        return await self.call('hotkey', {'target':state['_target'], 'delivery_mode':'background','keys':keys})
