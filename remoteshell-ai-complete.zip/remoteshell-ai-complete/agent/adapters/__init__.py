"""Verified external integration boundaries."""
