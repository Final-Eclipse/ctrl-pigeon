import asyncio
import io
import uuid
from datetime import datetime
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from agent.safety import output_path
from agent.adapters.cua import command, AppLaunchError

async def create_presentation(topic, n_slides=3, *, planner, cua, checkpoint):
    n_slides = int(n_slides)
    if not 1 <= n_slides <= 12:
        raise ValueError('Choose between 1 and 12 slides')
    if 'path' not in checkpoint:
        deck = checkpoint.get('deck')
        if deck is None:
            deck = await planner.deck(topic,n_slides)
            if len(deck.slides) != n_slides:
                raise RuntimeError('Model returned the wrong slide count')
            checkpoint['deck'] = deck
        try:
            presentation = Presentation()
            presentation.slide_width = Inches(13.333)
            presentation.slide_height = Inches(7.5)
            for index, content in enumerate(deck.slides):
                slide = presentation.slides.add_slide(presentation.slide_layouts[6])
                slide.background.fill.solid()
                slide.background.fill.fore_color.rgb = RGBColor(13,20,35)
                title = slide.shapes.add_textbox(Inches(.8), Inches(.8), Inches(11.7), Inches(1.4)).text_frame
                title.word_wrap = True
                p = title.paragraphs[0]; p.text = content.title
                p.font.size = Pt(34);p.font.bold = True;p.font.color.rgb = RGBColor(100,230,210)
                body = slide.shapes.add_textbox(Inches(1),Inches(2.5),Inches(11.2),Inches(3.7)).text_frame
                body.word_wrap = True
                for i, bullet in enumerate(content.bullets):
                    p = body.paragraphs[0] if i == 0 else body.add_paragraph()
                    p.text = '• '+bullet[:180];p.font.size = Pt(24)
                    p.font.color.rgb = RGBColor(240,244,250);p.space_after = Pt(22)
                footer = slide.shapes.add_textbox(Inches(.8),Inches(6.9),Inches(11),Inches(.3)).text_frame.paragraphs[0]
                footer.text = f'REMOTESHELL AI   /   {index+1:02d}'
                footer.font.size = Pt(11);footer.font.color.rgb = RGBColor(150,164,185)
            buf = io.BytesIO(); presentation.save(buf)
            path = output_path('RemoteShell_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:6]+'.pptx')
            with path.open('xb') as f:
                f.write(buf.getvalue())
            checkpoint['path'] = path
        except (OSError, ValueError) as exc:
            raise RuntimeError('Presentation could not be written to Desktop') from exc
    path = checkpoint['path']
    if 'opened' not in checkpoint:
        errors=[]
        for app in ['Keynote','Microsoft PowerPoint']:
            try:
                # -g preserves focus. A foreground-only import dialog requires manual setup.
                await command('open','-g','-a',app,str(path),timeout=10)
                checkpoint['app'] = app
                for _ in range(10):
                    windows = await cua.list_windows(app)
                    if any(path.stem in w.get('title','') for w in windows):
                        checkpoint['opened'] = True
                        break
                    await asyncio.sleep(.5)
                if checkpoint.get('opened'):
                    break
            except Exception as exc:
                errors.append(type(exc).__name__)
        if not checkpoint.get('opened'):
            raise AppLaunchError('Deck saved, but its document window was not verified; dismiss import dialogs manually')
    return f'✅ Created {n_slides} slides and verified the deck window in {checkpoint["app"]}: {path.name}'
