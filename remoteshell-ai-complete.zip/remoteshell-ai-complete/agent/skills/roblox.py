import asyncio
import base64
import os
import re
import uuid
from agent.adapters.cua import command, AppLaunchError, ElementNotFoundError
from agent.safety import output_path

async def launch_roblox_match(*, cua, checkpoint, planner):
    place = os.environ.get('ROBLOX_PLACE_ID','')
    if not re.fullmatch(r'[1-9][0-9]{0,19}',place):
        raise ValueError('Set ROBLOX_PLACE_ID to your tested experience ID')
    if not checkpoint.get('requested'):
        # VERIFY: rehearse the experience deep link with this installed Roblox client:
        # https://create.roblox.com/docs/production/promotion/deeplinking
        await command('open','-g',f'roblox://experiences/start?placeId={place}',timeout=10)
        checkpoint['requested'] = True
    for _ in range(45):
        if await cua.list_windows('Roblox'):
            break
        await asyncio.sleep(1)
    else:
        raise AppLaunchError('Roblox window did not appear within 45 seconds')
    label=os.environ.get('ROBLOX_PLAY_LABEL','').strip()
    if not label:
        return '🎮 Roblox launched — match loading. Window verified; joining the match is not yet verified.'
    # This configured skill permits one Play action, never arbitrary Roblox typing/chat.
    async def observe():
        state=await cua.get_ui_tree('Roblox')
        if not state.get('elements'):
            path=output_path('RemoteShell_'+uuid.uuid4().hex+'.png')
            try:
                state=await cua.screenshot('Roblox',path)
                state['vision']=await planner.vision(base64.b64encode(path.read_bytes()).decode(),
                    'Describe gameplay or menu state. If a button has exact label '+repr(label)+', give its center x,y in screenshot pixels. Do not return coordinates for any other control.')
            finally:
                try:path.unlink(missing_ok=True)
                except OSError:pass
        return state
    state=await observe()
    if not checkpoint.get('play_attempted'):
        if state.get('elements'):
            params={'label':label}
            cua.element(state,label)
        else:
            vision=state.get('vision',{})
            if not all(isinstance(vision.get(k),(int,float)) for k in ['x','y']):
                raise ElementNotFoundError('Configured Play button is not visible')
            params={'x':vision['x'],'y':vision['y'],'capture_id':state.get('capture_id')}
        # Mark before mutation: an interrupted click may have landed and must not be replayed.
        checkpoint['play_attempted']=True
        await cua.click('Roblox',params,state)
        await asyncio.sleep(1)
        state=await observe()
    if not await planner.verify('The configured experience has visibly entered active gameplay, not a Play menu, loading screen, login or purchase screen.',state):
        raise RuntimeError('Roblox Play was requested, but gameplay is not yet verified; no duplicate click sent')
    return '🎮 Roblox launched — match loading. Gameplay was observed after the configured Play action.'
