"""Deterministic demo skills."""
