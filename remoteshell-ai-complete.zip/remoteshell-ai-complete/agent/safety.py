import re
from pathlib import Path

class SafetyError(Exception):
    pass

APPS = {'Keynote', 'Microsoft PowerPoint', 'Roblox', 'Calculator', 'TextEdit'}
DENIED = re.compile(r'(?i)(rm\s+-[^\n]*r|\bsudo\b|curl[^\n]*\|\s*(?:sh|bash)|\bdiskutil\b|keychain|\bpassword\b|do\s+shell\s+script|\bactivate\b)')


def check_step(step):
    if step.target_app and step.target_app not in APPS:
        raise SafetyError('App is outside the configured allowlist')
    if DENIED.search(str(step.params)):
        raise SafetyError('Blocked command or sensitive operation')
    allowed = {
        'open_app': set(), 'open_url': {'skill'},
        'run_applescript': {'template'},
        'create_file': {'skill','topic','n_slides','filename','content'},
        'click': {'label','x','y','capture_id'},
        'type_text': {'label','text'}, 'key_combo': {'keys'},
        'wait_for': {'contains'}, 'screenshot': set(), 'reply': {'text'},
    }
    if set(step.params) - allowed[step.action]:
        raise SafetyError('Unexpected action parameters')
    if step.action == 'open_url' and step.params.get('skill') != 'launch_roblox_match':
        raise SafetyError('Only the configured Roblox deep link is permitted')
    if step.action == 'run_applescript' and step.params.get('template') != 'keynote_document_count':
        raise SafetyError('Only the fixed read-only AppleScript template is permitted')
    if step.action in {'click','type_text','key_combo'} and step.target_app != 'Calculator':
        raise SafetyError('Generic UI input is limited to Calculator in this demo build')
    if step.action == 'type_text' and not re.fullmatch(r'[0-9.+*/() =\-]{1,100}',step.params.get('text','')):
        raise SafetyError('Only calculator expressions are permitted')
    if step.action == 'key_combo' and step.params.get('keys') not in [['cmd','c'],['cmd','a']]:
        raise SafetyError('Key combination is outside the allowlist')
    if step.action == 'create_file' and step.params.get('skill') not in {None,'create_presentation'}:
        raise SafetyError('Unknown file generation skill')


def output_path(filename):
    if not re.fullmatch(r'RemoteShell_[A-Za-z0-9_-]+\.(txt|pptx|png)', filename):
        raise SafetyError('Output must be a new RemoteShell file on Desktop')
    root = Path.home() / 'Desktop'
    if root.is_symlink():
        raise SafetyError('Desktop symlink is not permitted')
    p = root / filename
    if p.exists() or p.is_symlink():
        raise SafetyError('Will not overwrite an existing file')
    return p
