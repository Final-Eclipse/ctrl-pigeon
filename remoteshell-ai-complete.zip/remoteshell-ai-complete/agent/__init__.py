"""RemoteShell AI macOS agent."""
