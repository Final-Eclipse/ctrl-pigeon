import asyncio
import base64
import json
import logging
import os
import uuid
from agent.adapters.cua import Cua, command, ClickMissedError, ActionTimeoutError
from agent.planner import Planner
from agent.safety import check_step, output_path, SafetyError
from agent.skills.slides import create_presentation
from agent.skills.roblox import launch_roblox_match

log = logging.getLogger('remoteshell')
RETRY = '⚠️ Task failed, retrying...'

class Executor:
    def __init__(self, emit):
        self.emit=emit;self.cua=Cua();self.planner=Planner();self.checkpoints={}

    async def observe(self, app, question='Describe this window'):
        state = await self.cua.get_ui_tree(app)
        if not state.get('elements'):
            path=output_path('RemoteShell_'+uuid.uuid4().hex+'.png')
            try:
                state=await self.cua.screenshot(app,path)
                image=base64.b64encode(path.read_bytes()).decode()
                state['vision']=await self.planner.vision(image,question)
            except OSError as exc:
                raise RuntimeError('Window screenshot unavailable') from exc
            finally:
                try:
                    path.unlink(missing_ok=True)
                except OSError:
                    log.warning('temporary_screenshot_cleanup_failed')
        return state

    async def act(self, s, state):
        p=s.params;action=s.action;checkpoint=self.checkpoints.setdefault(s.id,{})
        if action=='create_file' and p.get('skill')=='create_presentation':
            return await create_presentation(p.get('topic','RemoteShell AI'),p.get('n_slides',3),planner=self.planner,cua=self.cua,checkpoint=checkpoint)
        if action=='open_url':
            return await launch_roblox_match(cua=self.cua,checkpoint=checkpoint,planner=self.planner)
        if action=='open_app':
            await self.cua.open_app(s.target_app)
            if not await self.cua.list_windows(s.target_app):
                raise RuntimeError('App launched without a verified window')
            return '✅ '+s.target_app+' window found.'
        if action=='run_applescript':
            result=await command('osascript','-e','tell application "Keynote" to count documents')
            return 'Keynote open document count: '+result.strip()
        if action=='create_file':
            if not checkpoint.get('path'):
                path=output_path(p['filename'])
                try:
                    content=p['content']
                    if not isinstance(content,str) or len(content)>50000:
                        raise SafetyError('Text file content must be at most 50,000 characters')
                    with path.open('x') as f:f.write(content)
                    if path.read_text()!=content:raise RuntimeError('File verification failed')
                    checkpoint['path']=path
                except OSError as exc:
                    raise RuntimeError('Text file write failed') from exc
            return '✅ Saved '+checkpoint['path'].name
        if action=='reply':return p['text'][:2000]
        if action=='screenshot':
            path=output_path('RemoteShell_'+uuid.uuid4().hex+'.png')
            await self.cua.screenshot(s.target_app,path)
            return '✅ Saved window screenshot: '+path.name
        if action=='wait_for':
            for _ in range(s.timeout_s):
                current=await self.observe(s.target_app)
                if p['contains'].casefold() in json.dumps(current).casefold():return '✅ Expected window text found.'
                await asyncio.sleep(1)
            raise RuntimeError('Expected state not observed')
        if action=='click':
            # Vision coordinates are grounded in this exact capture, never a desktop screenshot.
            if not p.get('label') and not state.get('elements') and state.get('vision'):
                v=state['vision']
                if all(isinstance(v.get(k),(int,float)) for k in ['x','y']):
                    p={**p,'x':v['x'],'y':v['y'],'capture_id':state.get('capture_id')}
            await self.cua.click(s.target_app,p,state)
        elif action=='type_text':await self.cua.type_text(s.target_app,p,state)
        elif action=='key_combo':await self.cua.key_combo(s.target_app,p['keys'],state)
        after=await self.observe(s.target_app,s.success_check)
        if not await self.planner.verify(s.success_check,after):
            raise ClickMissedError('Action returned but its outcome was not verified')
        return '✅ '+s.success_check

    async def run(self,text):
        await self.emit('Planning your request.')
        plan=None
        for attempt in range(2):
            try:
                plan=await self.planner.plan(text)
                break
            except Exception:
                if attempt:raise
                await self.emit(RETRY)
        steps=list(plan.steps);completed=[];executed=0
        retries=int(os.environ.get('MAX_RETRIES','2'))
        while steps:
            s=steps.pop(0);executed+=1
            if executed>12:raise RuntimeError('12-step execution limit reached')
            check_step(s)
            state={};result=None
            for attempt in range(retries+1):
                try:
                    async with asyncio.timeout(s.timeout_s):
                        if s.action in {'click','type_text','key_combo'}:
                            state=await self.observe(s.target_app,s.success_check)
                        result=await self.act(s,state)
                    break
                except SafetyError:
                    raise
                except Exception as exc:
                    log.warning(json.dumps({'step_id':s.id,'action':s.action,'error_type':type(exc).__name__,'attempt':attempt}))
                    if attempt>=retries:raise RuntimeError(str(exc)[:180]) from exc
                    await self.emit(RETRY)
                    if s.action in {'click','type_text','key_combo'}:
                        current=await self.observe(s.target_app,s.success_check)
                        if await self.planner.verify(s.success_check,current):
                            result='✅ Verified after re-observation.';break
                        # Unknown effects are not blindly replayed (typing/clicks may have landed).
                        if isinstance(exc,(TimeoutError,ActionTimeoutError)):
                            raise RuntimeError('Action timed out with an uncertain effect; stopped to avoid duplicate input') from exc
                        if attempt>=1:
                            replacement=await self.planner.plan(text,json.dumps({'completed':completed,'failed_step':s.model_dump(),'error':type(exc).__name__,'state':current,'instruction':'Replan remaining work; prefer next deterministic route, AX then vision. Never foreground.'}))
                            if any(item.target_app!=s.target_app for item in replacement.steps):
                                raise SafetyError('Recovery changed the target app')
                            if len(replacement.steps)!=1:
                                raise RuntimeError('Recovery must return one replacement step within the retry budget')
                            candidate=replacement.steps[0]
                            candidate.id=s.id
                            check_step(candidate)
                            s=candidate
                    await asyncio.sleep(.5)
            completed.append({'id':s.id,'result':result})
            await self.emit(result or 'Step completed.')
        return '✅ Request finished.'
