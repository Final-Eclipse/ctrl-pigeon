from typing import Literal
from pydantic import BaseModel, ConfigDict, Field, model_validator

class Strict(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True)

class Step(Strict):
    id: int = Field(ge=1, le=12)
    action: Literal['open_app','open_url','run_applescript','create_file','click','type_text','key_combo','wait_for','screenshot','reply']
    target_app: str
    params: dict
    success_check: str = Field(min_length=1, max_length=500)
    timeout_s: int = Field(default=15, ge=1, le=60)

class Plan(Strict):
    goal: str = Field(min_length=1, max_length=2000)
    steps: list[Step] = Field(min_length=1, max_length=12)

    @model_validator(mode='after')
    def unique_ids(self):
        if len({s.id for s in self.steps}) != len(self.steps):
            raise ValueError('Step IDs must be unique')
        return self

class Slide(Strict):
    title: str = Field(min_length=1, max_length=90)
    bullets: list[str] = Field(min_length=3, max_length=4)

class Deck(Strict):
    slides: list[Slide] = Field(min_length=1, max_length=12)

class TaskRequest(Strict):
    id: str = Field(pattern=r'^[a-f0-9-]{36}$')
    text: str = Field(min_length=1, max_length=4000)
