import asyncio
import hmac
import logging
import os
import time
from collections import OrderedDict
from contextlib import asynccontextmanager
from pathlib import Path
from dotenv import load_dotenv
from fastapi import FastAPI, Header, HTTPException
from agent.models import TaskRequest
from agent.gemini_agent import GeminiAgent as Executor
from agent.dashboard import install_dashboard, dashboard_url

load_dotenv(Path(__file__).with_name('.env'))
os.environ.setdefault('PLANNER_MODEL','nousresearch/hermes-3-llama-3.1-405b')
logging.basicConfig(level=logging.INFO,format='%(message)s')
log=logging.getLogger('remoteshell')
jobs=OrderedDict()
lock=asyncio.Lock()
SECRET=''
TIMEOUT=120

@asynccontextmanager
async def lifespan(app):
    global SECRET,TIMEOUT
    for key in ['AGENT_SHARED_SECRET','OPENROUTER_API_KEY','VISION_MODEL']:
        if not os.environ.get(key):raise RuntimeError('Missing required setting: '+key)
    SECRET=os.environ['AGENT_SHARED_SECRET']
    if len(SECRET)<32:raise RuntimeError('Shared secret must be at least 32 characters')
    TIMEOUT=int(os.environ.get('TASK_TIMEOUT_S','120'))
    if not 1<=TIMEOUT<=120:raise RuntimeError('TASK_TIMEOUT_S must be 1..120')
    if not 0<=int(os.environ.get('MAX_RETRIES','2'))<=2:raise RuntimeError('MAX_RETRIES must be 0..2')
    log.info('Dashboard: %s', dashboard_url())
    yield
    for job in jobs.values():
        if not job['task'].done():job['task'].cancel()
    await asyncio.gather(*(j['task'] for j in jobs.values()),return_exceptions=True)

app=FastAPI(lifespan=lifespan)
# RemoteShell dashboard integration
install_dashboard(app, jobs)

def auth(secret):
    if not secret or not hmac.compare_digest(secret.encode(),SECRET.encode()):
        raise HTTPException(401,'Unauthorized')

async def perform(job,text):
    async def emit(message):
        job['events'].append(str(message)[:2000])
    try:
        async with asyncio.timeout(TIMEOUT):
            async with lock:
                job['state']='running'
                result=await Executor(emit).run(text)
                await emit(result)
                job['state']='completed'
    except asyncio.CancelledError:
        job['state']='cancelled';await emit('🛑 Cancelled. Already completed actions are not undone.')
    except TimeoutError:
        job['state']='failed';await emit("❌ Couldn't complete: task exceeded its time limit. Server is still running — try rephrasing.")
    except Exception as exc:
        log.error('task_failed type=%s',type(exc).__name__)
        job['state']='failed';await emit("❌ Couldn't complete: "+str(exc)[:180]+'. Server is still running — try rephrasing.')
    finally:job['finished']=time.monotonic()

@app.get('/health')
async def health():return {'ok':True,'running':sum(j['state']=='running' for j in jobs.values())}

@app.post('/task')
async def task(body:TaskRequest,x_agent_secret:str|None=Header(default=None)):
    auth(x_agent_secret)
    if body.id in jobs:
        job=jobs[body.id]
        if not hmac.compare_digest(job['text'].encode(),body.text.encode()):raise HTTPException(409,'Task ID already used')
        return {'id':body.id,'state':job['state']}
    if any(j['state'] in {'queued','running'} for j in jobs.values()):raise HTTPException(409,'Agent is busy')
    # Keep IDs for one hour: a transport retry must never replay a completed task.
    for key in list(jobs):
        j=jobs[key]
        if j.get('finished') and time.monotonic()-j['finished']>3600:del jobs[key]
    if len(jobs)>=500:raise HTTPException(503,'Task receipt capacity reached; retry later')
    job={'state':'queued','events':[],'text':body.text}
    jobs[body.id]=job;job['task']=asyncio.create_task(perform(job,body.text))
    return {'id':body.id,'state':'queued'}

@app.get('/task/{task_id}')
async def state(task_id:str,after:int=0,x_agent_secret:str|None=Header(default=None)):
    auth(x_agent_secret)
    if task_id not in jobs:raise HTTPException(404,'Unknown task')
    j=jobs[task_id];after=max(0,after)
    return {'state':j['state'],'events':j['events'][after:],'next':len(j['events'])}

@app.post('/task/{task_id}/cancel')
async def cancel(task_id:str,x_agent_secret:str|None=Header(default=None)):
    auth(x_agent_secret)
    if task_id in jobs:
        job=jobs[task_id]
        job['task'].cancel()
        await asyncio.gather(job['task'],return_exceptions=True)
        if job['state']=='queued':
            job['state']='cancelled';job['finished']=time.monotonic()
    return {'ok':True}

if __name__=='__main__':
    import uvicorn
    uvicorn.run('agent.main:app',host='127.0.0.1',port=int(os.environ.get('AGENT_PORT','8765')),workers=1)
