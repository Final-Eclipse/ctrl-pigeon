# RemoteShell Gemini agent patch

Already integrated in this complete project. Follow README.md for setup.

## Try these, one at a time
- Write a short study plan and save it as study-plan.md.
- Make it shorter and save a new version as study-plan-short.md.
- Research three recent developments in solar energy, include source links, and save a summary as solar.md.
- List my workspace files.
- Read study-plan.md and suggest improvements.
- Create a 3-slide presentation about ocean conservation.
- Open Calculator.

Put UTF-8 .txt, .md or .csv input files directly in Desktop/RemoteShell Workspace. The folder is created on first file-tool use. File reads are limited to 60 KB and new writes to 30,000 characters. Existing files are never overwritten. PPTX outputs retain the original Desktop destination.

## What changed
A bounded tool loop chooses actions, receives real results, and decides the next step. Up to eight tool calls per task, within the existing 120-second agent limit. Single-user conversation memory retains four recent requests for up to an hour in RAM; restart or text `forget` to clear it. Cancellation/timeout receipts are retained to help avoid repeating completed work. The dashboard continues using the same progress events. Gateway `help` text is unchanged and lists the older capabilities.

Gemini can research the web, draft and revise content, read/list/create workspace text files, generate presentations, open allowlisted apps, inspect a single app window, and use the existing restricted Calculator input workflow. API/tool errors appear in progress. The model can still make mistakes; app observation does not establish general control of that app.

This is not unrestricted computer control. It does not edit arbitrary apps, browse signed-in websites, read PDF/Word files, convert files to PDF, run shell commands, delete/overwrite files, send messages to third parties, or purchase things. Those tools are absent, rather than pretending a confirmation unlocks them. App operations still depend on CuaDriver permissions and window state. It starts its named driver session before app use, handles structured refusals, and uses the list_windows contract observed on your installed driver.

Selected workspace file contents and task context are sent to your configured model provider when used. Public research uses OpenRouter's web plugin. No permanent memory database is added.

## Validation
Local mocked tool-loop, file boundary, follow-up memory, refusal and installer tests. No live paid Gemini call or Mac GUI test was performed here. Verify with the sample tasks on your Mac before a demo.

API references:
https://openrouter.ai/docs/guides/features/tool-calling
https://openrouter.ai/docs/guides/features/plugins/web-search
https://openrouter.ai/google/gemini-2.5-flash
