export class TaskQueue {
  private pending: Array<() => Promise<void>> = [];
  private working = false;
  private draining?: Promise<void>;
  private resolveDrain?: () => void;
  get size() { return this.pending.length + Number(this.working); }
  add(job: () => Promise<void>) {
    if (this.size >= 10) return false;
    this.pending.push(job);
    void this.run();
    return true;
  }
  clear() { const n = this.pending.length; this.pending = []; return n; }
  async drain() {
    if (!this.size) return;
    this.draining ??= new Promise<void>(resolve => { this.resolveDrain = resolve; });
    await this.draining;
  }
  private async run() {
    if (this.working) return;
    this.working = true;
    try {
      while (this.pending.length) {
        try { await this.pending.shift()!(); }
        catch { /* Task owner logs failures; keep the serial worker alive. */ }
      }
    } finally {
      this.working = false;
      this.resolveDrain?.(); this.draining = undefined; this.resolveDrain = undefined;
    }
  }
}
