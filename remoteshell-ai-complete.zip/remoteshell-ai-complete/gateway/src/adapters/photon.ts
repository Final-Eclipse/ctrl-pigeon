import { Spectrum, attachment, type Space } from 'spectrum-ts';
import { imessage } from '@spectrum-ts/imessage';
import { readFile } from 'node:fs/promises';
import { z } from 'zod';
import type { Logger } from 'pino';
import { allowed, normalize } from '../whitelist.js';

export type Inbound = { id: string; sender: string; text: string };
const messageShape = z.object({id:z.string(),direction:z.literal('inbound'),
  sender:z.object({id:z.string(),service:z.literal('iMessage')}),
  content:z.object({type:z.literal('text'),text:z.string()})});
const spaceShape = z.object({__platform:z.literal('imessage'),type:z.literal('dm')});
const sleep = (ms:number) => new Promise(resolve => setTimeout(resolve,ms));

async function bounded<T>(promise:Promise<T>,ms=8000):Promise<T> {
  let timer:ReturnType<typeof setTimeout>|undefined;
  try {
    return await Promise.race([promise,new Promise<never>((_,reject)=>{
      timer=setTimeout(()=>reject(new Error('Photon operation timed out')),ms);
    })]);
  } finally {if(timer)clearTimeout(timer);}
}

export class Photon {
  private app?: Awaited<ReturnType<typeof Spectrum>>;
  private routes = new Map<string,Space>();
  private stopping = false;
  constructor(private projectId:string, private projectSecret:string, private sender:string, private log:Logger) {}
  async listen(receive:(m:Inbound)=>Promise<void>) {
    let attempt=0;
    while (!this.stopping) {
      try {
        this.log.info({event:'photon_connecting'});
        // Verified 12.10.1: https://github.com/photon-hq/spectrum-ts
        this.app = await Spectrum({projectId:this.projectId,projectSecret:this.projectSecret,
          providers:[imessage.config()],telemetry:false,options:{logLevel:'error'}});
        this.log.info({event:'photon_connected'});
        for await (const [space,message] of this.app.messages) {
          if(this.stopping) break;
          attempt=0;
          const m=messageShape.safeParse(message);
          if(!m.success || !spaceShape.safeParse(space).success) continue;
          const {id,sender,content}=m.data;
          // Only authorized direct-message routes can be used for outgoing replies.
          if(allowed(sender.id,this.sender)) this.routes.set(normalize(sender.id)!,space);
          try { await receive({id,sender:sender.id,text:content.text}); }
          catch { this.log.error({event:'inbound_handler_failed'}); }
        }
        if(!this.stopping) throw new Error('Photon stream ended');
      } catch {
        if(!this.stopping) this.log.warn({event:'photon_disconnected',attempt});
      } finally {
        try { if(this.app) await bounded(this.app.stop()); } catch { this.log.warn({event:'photon_close_failed'}); }
        this.app=undefined;
      }
      if(!this.stopping) {
        const delay=Math.min(30_000,1000*2**Math.min(attempt++,5))*(.8+Math.random()*.2);
        this.log.info({event:'photon_reconnect_wait',delay_ms:Math.round(delay)});
        await sleep(delay);
      }
    }
  }
  async sendText(handle:string,text:string) {
    const space=this.routes.get(handle);
    if(!space || !allowed(handle,this.sender)) throw new Error('No authorized DM route');
    try { await bounded(space.send(text.slice(0,2500))); }
    catch { throw new Error('Photon reply failed'); }
  }
  async sendImage(handle:string,path:string) {
    const space=this.routes.get(handle);
    if(!space || !allowed(handle,this.sender)) throw new Error('No authorized DM route');
    try { const bytes=await readFile(path); await bounded(space.send(attachment(bytes,{mimeType:'image/png'}))); }
    catch { throw new Error('Photon image reply failed'); }
  }
  async close() {
    this.stopping=true;
    try { if(this.app) await bounded(this.app.stop()); } catch { this.log.warn({event:'photon_close_failed'}); }
  }
}
