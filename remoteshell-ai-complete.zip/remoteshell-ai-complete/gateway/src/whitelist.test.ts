import test from 'node:test';
import assert from 'node:assert/strict';
import { allowed, normalize, Seen, redacted } from './whitelist.js';
import { TaskQueue } from './queue.js';
const phone='+14045551234';
test('normalize and reject ambiguous/email identities',()=>{
  assert.equal(normalize('tel:+1 (404) 555-1234'),phone);
  assert.equal(normalize('mailto:+14045551234'),phone);
  for(const s of ['4045551234','ishan@example.com','+14045551234@evil.test','++14045551234','']) assert.equal(normalize(s),null);
  assert.equal(allowed('+1 404 555 1234',phone),true);
  assert.equal(allowed('+14045551235',phone),false);
  assert.equal(redacted('+14045551234'),'***1234');
});
test('dedupe holds 500 most recently seen IDs',()=>{
  const seen=new Seen();assert.equal(seen.hasOrAdd('a'),false);assert.equal(seen.hasOrAdd('a'),true);
  for(let i=0;i<500;i++)seen.hasOrAdd(String(i));
  assert.equal(seen.hasOrAdd('a'),false);
});
test('queue serializes and survives a failing task',async()=>{
  const q=new TaskQueue();const order:number[]=[];
  q.add(async()=>{order.push(1);await new Promise(r=>setTimeout(r,10));order.push(2);throw new Error('failure');});
  q.add(async()=>{order.push(3);});
  await q.drain();assert.deepEqual(order,[1,2,3]);assert.equal(q.size,0);
});
