import { createHash, timingSafeEqual } from 'node:crypto';
export function normalize(raw: string): string | null {
  const value = raw.trim().replace(/^(?:tel:|mailto:)/i, '').replace(/[\s().-]/g, '');
  // Emails and ambiguous national numbers are never guessed into an allowed identity.
  return /^\+[1-9]\d{7,14}$/.test(value) ? value : null;
}
export function allowed(raw: string, expected: string): boolean {
  const hash = (s: string) => createHash('sha256').update(s).digest();
  return timingSafeEqual(hash(normalize(raw) ?? ''), hash(expected));
}
export function redacted(raw: string): string { return '***' + raw.replace(/\D/g, '').slice(-4); }
export class Seen {
  private ids = new Map<string, true>();
  hasOrAdd(id: string): boolean {
    if (this.ids.has(id)) { this.ids.delete(id); this.ids.set(id,true); return true; }
    this.ids.set(id, true);
    if (this.ids.size > 500) this.ids.delete(this.ids.keys().next().value!);
    return false;
  }
}
