import 'dotenv/config';
import { randomUUID } from 'node:crypto';
import { homedir } from 'node:os';
import { join } from 'node:path';
import { setTimeout as sleep } from 'node:timers/promises';
import { z } from 'zod';
import pino from 'pino';
import { Photon, type Inbound } from './adapters/photon.js';
import { allowed, normalize, redacted, Seen } from './whitelist.js';
import { TaskQueue } from './queue.js';

const log=pino();
const schema=z.object({
  ALLOWED_SENDER:z.string().regex(/^\+[1-9]\d{7,14}$/),
  PHOTON_PROJECT_ID:z.string().min(1),PHOTON_PROJECT_SECRET:z.string().min(1),
  AGENT_SHARED_SECRET:z.string().min(32),
  AGENT_PORT:z.coerce.number().int().min(1024).max(65535).default(8765),
  TASK_TIMEOUT_S:z.coerce.number().int().min(1).max(120).default(120),
});
const result=schema.safeParse(process.env);
if(!result.success) {
  // Print field names only; never serialize environment values or credentials.
  log.fatal({event:'invalid_config',fields:result.error.issues.map(i=>i.path.join('.'))});
  process.exit(1);
}
const env=result.data;
const photon=new Photon(env.PHOTON_PROJECT_ID,env.PHOTON_PROJECT_SECRET,env.ALLOWED_SENDER,log);
const seen=new Seen();const queue=new TaskQueue();let accepting=true;
let active:string|undefined;let cancelRequested=false;
const base=`http://127.0.0.1:${env.AGENT_PORT}`;
const retryText='⚠️ Task failed, retrying...';
async function reply(text:string) {
  try { await photon.sendText(env.ALLOWED_SENDER,text); }
  catch { log.warn({event:'reply_delivery_failed'}); }
}
async function request(path:string,body?:unknown,timeout=5000) {
  try {
    const r=await fetch(base+path,{method:body===undefined?'GET':'POST',
      headers:{'content-type':'application/json','x-agent-secret':env.AGENT_SHARED_SECRET},
      body:body===undefined?undefined:JSON.stringify(body),signal:AbortSignal.timeout(timeout)});
    if(!r.ok) throw new Error(`Agent HTTP ${r.status}`);
    return await r.json();
  } catch(error) { throw error; }
}
const stateSchema=z.object({state:z.enum(['queued','running','completed','cancelled','failed']),
  events:z.array(z.string()),next:z.number().int()});
async function run(text:string) {
  const id=randomUUID();active=id;cancelRequested=false;
  const deadline=Date.now()+(env.TASK_TIMEOUT_S+10)*1000;
  try {
    let started=false;
    for(let attempt=0;attempt<2;attempt++) {
      try {
        if(cancelRequested) return;
        // Same task ID on retry provides process-lifetime idempotency.
        await request('/task',{id,text},5000);started=true;break;
      } catch {
        if(attempt===0) { await reply(retryText);await sleep(3000); }
      }
    }
    if(!started) {await reply('❌ Agent offline or unavailable. Check the Mac agent terminal.');return;}
    if(cancelRequested) {await request(`/task/${id}/cancel`,{});return;}
    let cursor=0;let pollFailures=0;
    while(Date.now()<deadline) {
      if(cancelRequested) {await request(`/task/${id}/cancel`,{});return;}
      try {
        const state=stateSchema.parse(await request(`/task/${id}?after=${cursor}`));
        pollFailures=0;
        for(const event of state.events) {
          await reply(event);
          const image=event.match(/^✅ Saved window screenshot: (RemoteShell_[a-f0-9]{32}\.png)$/);
          if(image) {
            try {await photon.sendImage(env.ALLOWED_SENDER,join(homedir(),'Desktop',image[1]));}
            catch {await reply('Screenshot saved on Mac; image delivery failed.');}
          }
        }
        cursor=state.next;
        if(['completed','cancelled','failed'].includes(state.state)) return;
      } catch {
        if(++pollFailures===1) await reply(retryText);
        if(pollFailures>=3) throw new Error('Agent connection lost');
      }
      await sleep(500);
    }
    throw new Error('Task monitoring timed out');
  } catch {
    try {await request(`/task/${id}/cancel`,{});} catch {log.warn({event:'cancel_unconfirmed'});}
    await reply("❌ Couldn't complete: connection or timeout failure; outcome may be uncertain. Server is still running — try rephrasing.");
  } finally {active=undefined;cancelRequested=false;}
}
async function inbound(m:Inbound) {
  if(!accepting || seen.hasOrAdd(m.id)) return;
  if(!allowed(m.sender,env.ALLOWED_SENDER)) {
    log.info({event:'sender_dropped',sender:redacted(m.sender)});return;
  }
  if(normalize(m.sender)!==env.ALLOWED_SENDER) return;
  const text=m.text.trim();const cmd=text.toLowerCase();
  if(cmd==='help') {await reply('Try: Write a study plan and save as plan.md; Research AI in sports with sources; Create a 3-slide presentation; Open Calculator. Commands: status, cancel, help, forget (AI memory). Files: Desktop/RemoteShell Workspace. General app control is limited.');return;}
  if(cmd==='status') {await reply(`🛰️ ${active?'Working':'Idle'}; ${queue.size} active/queued task(s).`);return;}
  if(cmd==='cancel') {
    const count=queue.clear();cancelRequested=true;
    if(active) {
      try {await request(`/task/${active}/cancel`,{});await reply(`🛑 Cancellation requested; cleared ${count} queued task(s).`);}
      catch {await reply('⚠️ Could not confirm cancellation. Check the Mac.');}
    } else await reply(`🛑 Cleared ${count} queued task(s).`);
    return;
  }
  if(!text || text.length>4000) {await reply('Send a command between 1 and 4,000 characters.');return;}
  if(queue.size>=10) {await reply('Queue is full. Send status or cancel.');return;}
  await reply(`🛰️ On it: "${text.slice(0,60)}"`);
  queue.add(()=>run(text));
}
let shuttingDown=false;
async function shutdown() {
  if(shuttingDown)return;shuttingDown=true;accepting=false;
  log.info({event:'shutdown_draining',tasks:queue.size});
  // Keep the authenticated transport alive while draining so final replies can be delivered.
  await queue.drain();await photon.close();
  process.exitCode=0;
}
process.on('SIGINT',()=>{void shutdown();});
process.on('SIGTERM',()=>{void shutdown();});
process.on('unhandledRejection',()=>{log.error({event:'unhandled_rejection'});});
process.on('uncaughtException',()=>{log.error({event:'uncaught_exception'});});
void photon.listen(inbound).catch(()=>log.error({event:'photon_listener_failed'}));
