# Dashboard

Already integrated. Start the Python agent and open the FULL Dashboard URL it prints, including #token=... . A new link is generated after each restart.

The dashboard shows current task progress and up to 25 recent tasks. It indicates agent connectivity, not Photon connectivity. History is in memory and resets on restart.
