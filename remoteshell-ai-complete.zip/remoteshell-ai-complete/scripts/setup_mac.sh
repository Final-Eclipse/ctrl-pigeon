#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
export PATH="$HOME/.local/bin:$PATH"
if ! command -v node >/dev/null || ! node -e 'process.exit(Number(process.versions.node.split(".")[0]) >= 24 ? 0 : 1)'; then
  command -v brew >/dev/null || { echo 'Install Node 24+ and Python 3.11, or install Homebrew first.'; exit 1; }
  brew install node@24
  export PATH="$(brew --prefix node@24)/bin:$PATH"
fi
if command -v python3.11 >/dev/null; then
  python_bin="$(command -v python3.11)"
elif [ -x /opt/homebrew/opt/python@3.11/bin/python3.11 ]; then
  python_bin=/opt/homebrew/opt/python@3.11/bin/python3.11
else
  command -v brew >/dev/null || { echo 'Install Python 3.11 first.'; exit 1; }
  brew install python@3.11
  python_bin="$(brew --prefix python@3.11)/bin/python3.11"
fi
[ -x .venv/bin/python ] || "$python_bin" -m venv .venv
.venv/bin/python -m pip install -r agent/requirements.txt
(cd gateway && npm ci && npm run check)
[ -f gateway/.env ] || cp gateway/.env.example gateway/.env
[ -f agent/.env ] || cp agent/.env.example agent/.env
chmod 600 gateway/.env agent/.env
cat <<'TEXT'
Dependencies installed. Fill in gateway/.env and agent/.env.
Install the signed CuaDriver macOS application using https://cua.ai/docs/cua-driver/quickstart.
Keep the CLI and daemon versions compatible; this project pins Python cua-driver 0.34.1.
Run: open -n -g -a CuaDriver --args serve
Run: cua-driver check_permissions
System Settings > Privacy & Security > Accessibility: enable CuaDriver.
System Settings > Privacy & Security > Screen & System Audio Recording: enable CuaDriver.
On older macOS versions the second panel is named Screen Recording.
Relaunch the driver when macOS asks. No microphone permission is needed.
TEXT
