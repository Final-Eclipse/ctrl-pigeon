from pathlib import Path
import shutil
import time
import os
import tempfile

root=Path.cwd()
main=root/'agent/main.py'
source=Path(__file__).resolve().parent/'gemini_agent.py'
if not main.is_file():raise SystemExit('Run this from your remoteshell-ai folder.')
original=main.read_text()
old='from agent.executor import Executor'
new='from agent.gemini_agent import GeminiAgent as Executor'
if new not in original and original.count(old)!=1:
    raise SystemExit('Unexpected main.py. No files changed. Share main.py, not .env, for a compatible patch.')
updated=original.replace(old,new)
compile(updated,str(main),'exec');compile(source.read_text(),str(source),'exec')
backup=root/'gemini-backups'/str(time.time_ns())
backup.mkdir(parents=True)
shutil.copy2(main,backup/'main.py')
module=root/'agent/gemini_agent.py'
if module.exists():shutil.copy2(module,backup/'gemini_agent.py')
shutil.copy2(source,module)
with tempfile.NamedTemporaryFile(mode='w',dir=main.parent,delete=False) as f:
    f.write(updated);temp=Path(f.name)
os.chmod(temp,main.stat().st_mode);os.replace(temp,main)
print('Gemini loop installed. Backup:',backup)
print('Restart your Python agent. Keep your gateway running. No new key needed.')
print('Model defaults to google/gemini-2.5-flash through your existing OpenRouter account.')
print('Input/output text folder: ~/Desktop/RemoteShell Workspace')
