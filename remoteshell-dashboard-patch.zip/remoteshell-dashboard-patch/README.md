# RemoteShell local dashboard

A read-only task monitor for your existing Python agent. No extra dependencies.

1. Extract this ZIP in Downloads.
2. In the existing Python agent terminal, press Control+C.
3. Run:

```sh
cd "$HOME/Downloads/remoteshell-ai"
.venv/bin/python "$HOME/Downloads/remoteshell-dashboard-patch/install_dashboard.py"
export PATH="$HOME/.local/bin:$PATH"
.venv/bin/python -m agent.main
```

4. Open the full `Dashboard: http://127.0.0.1:8765/dashboard#token=...` link printed in that terminal. Keep the gateway running in its other terminal.
5. Send a supported task through your existing iMessage conversation.

The link is private to this agent session. Restarting the agent creates a new link and clears task history. The UI shows agent reachability, not Photon connection status. Counts reflect retained agent records; the latest 25 tasks are selectable, each with its latest 60 events. Existing agent retention rules still apply. No task submission or cancellation controls are added.

The installer adds agent/dashboard.py and agent/dashboard.html and three integration lines in agent/main.py. Existing main.py and dashboard assets are backed up under dashboard-backups/<timestamp>. It does not change environment files or the Cua adapter. Running the installer again will not duplicate the integration.

To uninstall, stop the agent and restore agent/main.py from the first dashboard backup. The unused dashboard files can be removed. Restart the agent as usual.

Validated with local FastAPI endpoint tests and installer checks; the full Mac/iMessage workflow must be checked on your Mac.
