"""Run from your existing remoteshell-ai project root."""
import argparse
import os
from pathlib import Path
import shutil
import tempfile
import time

def install(root):
    source = Path(__file__).resolve().parent
    main = root / 'agent' / 'main.py'
    if not main.is_file():
        raise SystemExit('Run this from the remoteshell-ai folder, or pass --project /path/to/remoteshell-ai')
    original = main.read_text()
    marker = '# RemoteShell dashboard integration'
    updated = original
    if marker not in original:
        changes = [
            ('from agent.executor import Executor\n', 'from agent.executor import Executor\nfrom agent.dashboard import install_dashboard, dashboard_url\n'),
            ('app=FastAPI(lifespan=lifespan)\n', 'app=FastAPI(lifespan=lifespan)\n'+marker+'\ninstall_dashboard(app, jobs)\n'),
            ('    yield\n', "    log.info('Dashboard: %s', dashboard_url())\n    yield\n")
        ]
        for old, new in changes:
            if updated.count(old) != 1:
                raise SystemExit('Your agent/main.py differs from the expected version. No files changed. Share main.py for a compatible patch (not your .env).')
            updated = updated.replace(old, new)
    compile(updated, str(main), 'exec')
    for name in ('dashboard.py', 'dashboard.html'):
        if not (source / name).is_file():
            raise SystemExit('Keep all patch files together in the extracted folder.')
    backup = root / 'dashboard-backups' / str(time.time_ns())
    backup.mkdir(parents=True)
    shutil.copy2(main, backup / 'main.py')
    for name in ('dashboard.py', 'dashboard.html'):
        target = main.parent / name
        if target.exists():
            shutil.copy2(target, backup / name)
        shutil.copy2(source / name, target)
    with tempfile.NamedTemporaryFile(mode='w', dir=main.parent, delete=False) as out:
        out.write(updated)
        temp = Path(out.name)
    os.chmod(temp, main.stat().st_mode)
    os.replace(temp, main)
    print('Dashboard installed. Backup:', backup)
    print('Restart the Python agent, then open its printed Dashboard link.')

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--project', type=Path, default=Path.cwd())
    install(parser.parse_args().project.resolve())
